import React from 'react';

const CamperListItem = ({ camper, number, image }) => {
  return (
    <tr>
      <td>{number}</td>
      <td><a href={`https://freecodecamp.com/${camper.username}`} target="_blank"><img className="profile" src={image} alt="User Profile Picture"></img>&nbsp;{camper.username}</a></td>
      <td>{camper.recent}</td>
      <td>{camper.alltime}</td>
    </tr>
  );
}

export default CamperListItem;
