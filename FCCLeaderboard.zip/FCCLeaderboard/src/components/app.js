import React, { Component } from 'react';
import axios from 'axios';
import MDSpinner from 'react-md-spinner';

import CamperList from './camper_list.js';


export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      "Recent Campers": [],
      "All Time Campers": [],
      currentView: 'Recent Campers'
    };
  }


  componentWillMount() {
    axios.all([this.fetchRecentCampers(), this.fetchAllTimeCampers()])
      .then(axios.spread((recentCampers, allTimeCampers) => {
        this.setState({
          "Recent Campers": recentCampers.data,
          "All Time Campers": allTimeCampers.data
        });
      }));

  }

  fetchRecentCampers() {
    return axios.get('https://fcctop100.herokuapp.com/api/fccusers/top/recent');
  }

  fetchAllTimeCampers() {
    return axios.get('https://fcctop100.herokuapp.com/api/fccusers/top/alltime');
  }


  changeView(currentView) {
    this.setState({ currentView });
  }

  render() {
    if (!this.state["Recent Campers"].length && !this.state["All Time Campers"].length) {
      return <center><MDSpinner className="spinner" size={300}/></center>
    }
    return (
      <div>
        <h2>{`Viewing Top ${this.state.currentView}`}</h2>
        <button onClick={() => this.changeView('Recent Campers')} className="btn btn-primary col-xl-6">Recent</button>
        <button onClick={() => this.changeView('All Time Campers')} className="btn btn-danger col-xl-6">All Time</button>
        <CamperList campers={this.state[this.state.currentView]}/>
      </div>
    );
  }
}
